Name: Roy Xia
Student Number: 101009419
Date of Submission: 11/16/17
Assignment Number 4

Code written and tested with Dr.Racket R5S5.

Contour diagrams hand drawn.

Test cases provided with questions that require testing.

All questions are assumingly correct except question 4

question 4
(lambda ((input (read)))
    (lambda ((output (eval input the-global-environment)))

I used the special form of let lambda within the main loop, but i dont know what to do after this


