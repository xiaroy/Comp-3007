Name: Roy Xia
Student Number: 101009419

All code written and tested with Dr.Racket R5S5. Test cases provided with each question.

question 4 
I dont know the conditions dont work so the score never changes and not iterative.

question 7 
not done




