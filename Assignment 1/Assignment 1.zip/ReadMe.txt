Name: Roy Xia
Student Number: 101009419

All code written and tested with Dr.Racket R5S5. Test cases provided with each question. Everything should be right.
