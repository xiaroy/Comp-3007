Roy Xia
101009419
COMP3007 Assignment 5
2017/12/07

done with Notepad++ and Swi-Prolog

Ps. 5.D is incomplete everything else is right and tested at the bottom of each file